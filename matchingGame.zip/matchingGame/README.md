# Memory Game Project

# Project goal

This game is a card matching simulation.  It used CSS, HTML and Javascript to accomplish this task.

# HTML Notes

The cardBox class is how I divided the page to simulate a playing card. Flipped and unFlipped is how I assigned 2 pictures to the "card"
to be swapped later using css and javascript. This section is the main part of the page and how is predominately how the user will
interact with the page.


# CSS Notes

The main portion to take note is the break point near the bottom of the code. @media screen and (max-width: 649px)  This will make the game playable
on a smaller device.  The transform sections are used for the 3D animations and the backface hidden is used in the swapping of the pictures.

# JavaScript Notes

All of the hard work is done with JavaScript, from starting the clock, arranging and flipping the cards to calculating the score. See the code
comments for the sections to see all that gets accomplished and where.
