const cards = document.querySelectorAll('.cardBox');

// Setting  variables

let hasFlippedCard = false;
let lockBoard = false;
let firstCard, secondCard;
let count = 0;
let matchedCards = 0;
let secs = 0;
let score = 0;


// Timer section - 1000 is to convert to 1 second

window.onload = function() {

// var secs =0;
  var id = setInterval(function(){
      secs++;

  },1000);


};

// Flips cards and stores results

function flipCard() {
  if (lockBoard) return;
  if (this === firstCard) return;

  this.classList.add('flip');

  if (!hasFlippedCard) {
    // first click
    hasFlippedCard = true;
    firstCard = this;

    return;
  }

  // second click
  secondCard = this;

  checkForMatch();
}

// checks for a match, calls disableCards if it does, unflipCards if it doesn't match
function checkForMatch() {
  let isMatch = firstCard.dataset.framework === secondCard.dataset.framework;

  isMatch ? disableCards() : unflipCards();
  count == count ++
  console.log("count " + count);
  console.log("matched cards " + matchedCards);

}

// if matches, it leaves the cards flipped over.

function disableCards() {
  firstCard.removeEventListener('click', flipCard);
  secondCard.removeEventListener('click', flipCard);
  matchedCards == matchedCards ++;

// score calculation section

  if (matchedCards >= 8) {
    if (count <= 10){
      score = 3;
    }else if (count <= 20){
      score = 2;
    }else{
      score = 1;
    }

//  Winning message section
    alert("You Won!" + "\n" + "Matched: " + matchedCards + "\n" + "Attempts: " + count + "\n" + "Stars: " + score + "\n" + "Time: " + secs + " seconds");
  }


  resetBoard();
}

// if a card doesn't match it will flip the card back over
function unflipCards() {
  lockBoard = true;

  setTimeout(() => {
    firstCard.classList.remove('flip');
    secondCard.classList.remove('flip');


    resetBoard();
  }, 1500);
}


// sets up game board and puts card in random order

function resetBoard() {
  [hasFlippedCard, lockBoard] = [false, false];
  [firstCard, secondCard] = [null, null];
}

// randomizes the cardBox div sections for 16 cards/divs

(function shuffle() {
  cards.forEach(card => {
    let randomPos = Math.floor(Math.random() * 16);
    card.style.order = randomPos;
  });
})();

// this adds the mouse click listener for the cards, this is the most important line of code

cards.forEach(card => card.addEventListener('click', flipCard));
